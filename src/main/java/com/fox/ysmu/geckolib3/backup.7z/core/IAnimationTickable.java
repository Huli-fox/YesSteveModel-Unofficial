package com.fox.ysmu.geckolib3.core;

public interface IAnimationTickable {
	public int tickTimer();
}
