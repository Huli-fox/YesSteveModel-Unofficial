package com.fox.ysmu.geckolib3.model.provider.data;

public class EntityModelData {
    public boolean isSitting;
    public boolean isChild;
    public float netHeadYaw;
    public float headPitch;
}
