package com.fox.ysmu.geckolib3.core;

public enum PlayState {
	CONTINUE, STOP
}
