/*
 * Copyright (c) 2020.
 * Author: Bernie G. (Gecko)
 */

package com.fox.ysmu.geckolib3.core;

public enum AnimationState {
	Running, Transitioning, Stopped;
}
