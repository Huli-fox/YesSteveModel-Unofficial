package com.fox.ysmu.geckolib3.core.util;

public enum Axis {
	X, Y, Z
}
